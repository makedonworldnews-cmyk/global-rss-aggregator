import Parser from 'rss-parser';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const parser = new Parser({ timeout: 8000, headers: { 'User-Agent': 'MakedonWorldNews/3.0 RSS Bot' } });

// Читај ги сите извори од all_sources.json
const sourcesFile = path.join(__dirname, '..', 'sources', 'all_sources.json');
const allSources = JSON.parse(fs.readFileSync(sourcesFile, 'utf8'));
console.log(`📚 Вчитани ${allSources.length} извори.`);

const allItems = [];
let ok = 0, fail = 0;

async function fetchBatch(sources) {
  const results = await Promise.allSettled(
    sources.map(async source => {
      if (!source.url) return [];
      const feed = await parser.parseURL(source.url);
      return feed.items.slice(0, 3).map(item => ({
        title: item.title || 'Без наслов',
        link: item.link || '#',
        pubDate: item.pubDate || new Date().toISOString(),
        source: source.name,
        category: source.category || 'Свет',
        contentSnippet: item.contentSnippet || item.description || '',
        image: item.enclosure?.url || null,
      }));
    })
  );
  results.forEach((r, i) => {
    if (r.status === 'fulfilled') { allItems.push(...r.value); ok++; }
    else { fail++; }
  });
}

// Процесирај по 20 паралелно
const BATCH = 20;
for (let i = 0; i < allSources.length; i += BATCH) {
  await fetchBatch(allSources.slice(i, i + BATCH));
  const pct = Math.round((i + BATCH) / allSources.length * 100);
  process.stdout.write(`\r⏳ ${Math.min(i + BATCH, allSources.length)}/${allSources.length} (${pct}%) | OK:${ok} FAIL:${fail}`);
}

console.log(`\n✅ Готово! OK:${ok} FAIL:${fail}`);

// Сортирај по датум
allItems.sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate));

// Зачувај
const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
const outputPath = path.join(dataDir, 'feeds.json');
fs.writeFileSync(outputPath, JSON.stringify(allItems, null, 2));
console.log(`💾 Зачувани ${allItems.length} вести → ${outputPath}`);
